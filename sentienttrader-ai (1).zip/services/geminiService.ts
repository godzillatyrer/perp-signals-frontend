
import { GoogleGenAI, Type } from "@google/genai";
import { Kline, AnalysisResult, SignalType } from '../types';
import { ANALYST_SYSTEM_INSTRUCTION } from '../constants';

// --- CONFIGURATION ---
// Prioritized list of models. Will try in this order.
const MODELS_TO_TRY = ['gemini-3-flash-preview', 'gemini-3-pro-preview'];
const PRO_MODEL = 'gemini-3-pro-preview';

const getClient = () => {
  // Assuming process.env.API_KEY is available as per instructions
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

// Helper to format klines into a token-efficient string
const formatKlines = (klines: Kline[], timeframe: string): string => {
  return `${timeframe} Data:\n` + klines.map(k => 
    `T:${new Date(k.openTime).getHours()}h O:${k.open} H:${k.high} L:${k.low} C:${k.close} V:${k.volume}`
  ).join('\n');
};

const parseAnalysisResponse = (symbol: string, jsonString: string, modelName: string): AnalysisResult => {
    const result = JSON.parse(jsonString);

    let signalType = SignalType.NEUTRAL;
    if (result.signal === 'LONG') signalType = SignalType.LONG;
    if (result.signal === 'SHORT') signalType = SignalType.SHORT;
    if (result.signal === 'WAIT') signalType = SignalType.WAIT;

    return {
      symbol,
      timestamp: Date.now(),
      signal: signalType,
      confidence: result.confidence,
      timeframeConfidences: result.timeframeConfidences || [],
      entry: result.entry,
      tp: result.tp,
      sl: result.sl,
      leverage: result.leverage || "1x",
      support: result.support,
      resistance: result.resistance,
      keyFactors: result.keyFactors || [],
      reasoning: result.reasoning,
      modelUsed: modelName,
    };
};

export const analyzeMarket = async (symbol: string, context: Record<string, Kline[]>): Promise<AnalysisResult | null> => {
  const ai = getClient();
  let lastError: any = null;

  for (const modelName of MODELS_TO_TRY) {
    try {
      let contextString = "";
      Object.entries(context).forEach(([tf, klines]) => {
        if (klines.length > 0) {
          contextString += `\n\n${formatKlines(klines, tf)}`;
        }
      });
      const prompt = `Analyze ${symbol} using the provided timeframe data.\n${contextString}\n\nIdentify Trendlines, S/R levels, and calculate confidence for EACH provided timeframe. Focus on Capital Preservation.`;

      const response = await ai.models.generateContent({
        model: modelName,
        contents: prompt,
        config: {
          systemInstruction: ANALYST_SYSTEM_INSTRUCTION,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              signal: { type: Type.STRING, enum: ["LONG", "SHORT", "WAIT"] },
              confidence: { type: Type.NUMBER },
              timeframeConfidences: {
                 type: Type.ARRAY,
                 items: {
                    type: Type.OBJECT,
                    properties: {
                       timeframe: { type: Type.STRING },
                       confidence: { type: Type.NUMBER }
                    }
                 }
              },
              entry: { type: Type.STRING },
              tp: { type: Type.STRING },
              sl: { type: Type.STRING },
              leverage: { type: Type.STRING },
              support: { type: Type.STRING },
              resistance: { type: Type.STRING },
              keyFactors: { type: Type.ARRAY, items: { type: Type.STRING } },
              reasoning: { type: Type.STRING }
            },
            required: ["signal", "confidence", "timeframeConfidences", "entry", "tp", "sl", "leverage", "support", "resistance", "reasoning", "keyFactors"]
          }
        }
      });

      const text = response.text;
      if (!text) continue;

      return parseAnalysisResponse(symbol, text, modelName);

    } catch (error: any) {
      lastError = error;
      if (
        error.status === 429 || 
        error.message?.includes('429') || 
        error.message?.includes('quota') ||
        error.message?.includes('RESOURCE_EXHAUSTED')
      ) {
        console.warn(`Model ${modelName} rate-limited for ${symbol}. Trying next model...`);
        continue;
      }
      
      console.error(`Gemini Analysis Error for ${symbol} with model ${modelName}:`, error);
      return null;
    }
  }

  if (lastError) {
    throw lastError;
  }
  
  return null;
};

export const getSecondOpinion = async (symbol: string, context: Record<string, Kline[]>): Promise<AnalysisResult | null> => {
  const ai = getClient();
  const modelName = PRO_MODEL;

  try {
    let contextString = "";
    Object.entries(context).forEach(([tf, klines]) => {
      if (klines.length > 0) {
        contextString += `\n\n${formatKlines(klines, tf)}`;
      }
    });
    const prompt = `Provide a deep, second-opinion analysis for ${symbol} using this data.\n${contextString}\n\nRe-evaluate Trendlines, S/R, and confidence meticulously. Your primary goal is still CAPITAL PRESERVATION. Be extra critical of the initial thesis.`;

    const response = await ai.models.generateContent({
      model: modelName,
      contents: prompt,
      config: {
        systemInstruction: ANALYST_SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            signal: { type: Type.STRING, enum: ["LONG", "SHORT", "WAIT"] },
            confidence: { type: Type.NUMBER },
            timeframeConfidences: {
               type: Type.ARRAY,
               items: {
                  type: Type.OBJECT,
                  properties: {
                     timeframe: { type: Type.STRING },
                     confidence: { type: Type.NUMBER }
                  }
               }
            },
            entry: { type: Type.STRING },
            tp: { type: Type.STRING },
            sl: { type: Type.STRING },
            leverage: { type: Type.STRING },
            support: { type: Type.STRING },
            resistance: { type: Type.STRING },
            keyFactors: { type: Type.ARRAY, items: { type: Type.STRING } },
            reasoning: { type: Type.STRING }
          },
          required: ["signal", "confidence", "timeframeConfidences", "entry", "tp", "sl", "leverage", "support", "resistance", "reasoning", "keyFactors"]
        }
      }
    });

    const text = response.text;
    if (!text) {
      throw new Error("Received empty response from Pro model for second opinion.");
    }
    
    return parseAnalysisResponse(symbol, text, modelName);

  } catch (error: any) {
    console.error(`Gemini Second Opinion Error for ${symbol} with model ${modelName}:`, error);
    throw error;
  }
};